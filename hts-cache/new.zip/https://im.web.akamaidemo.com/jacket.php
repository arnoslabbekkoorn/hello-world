
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<meta http-equiv="Accept-CH" content="DPR, Viewport-Width, Width">
	<title>Thirty-One</title>
	<link rel="stylesheet" type="text/css" href="retail_files/styles.css">
	<script type='text/javascript'>
		/*
		var domain = '.akaimaging.com';
		var expires = new Date(); 
		expires.setDate(expires.getDate() + 365);
		document.cookie="im-pixel-density=" + window.devicePixelRatio + "; domain=" + domain + "; expires=" + expires + "; path=/";
		*/
	</script>	
<script>
(function(){
  if (window.BOOMR && window.BOOMR.version) { return; }
  var dom,doc,where,iframe = document.createElement("iframe"),win = window;

  function boomerangSaveLoadTime(e) {
    win.BOOMR_onload=(e && e.timeStamp) || new Date().getTime();
  }
  if (win.addEventListener) {
    win.addEventListener("load", boomerangSaveLoadTime, false);
  } else if (win.attachEvent) {
    win.attachEvent("onload", boomerangSaveLoadTime);
  }

  iframe.src = "javascript:void(0)";
  iframe.title = ""; iframe.role = "presentation";
  (iframe.frameElement || iframe).style.cssText = "width:0;height:0;border:0;display:none;";
  where = document.getElementsByTagName("script")[0];
  where.parentNode.insertBefore(iframe, where);

  try {
    doc = iframe.contentWindow.document;
  } catch(e) {
    dom = document.domain;
    iframe.src="javascript:var d=document.open();d.domain='"+dom+"';void(0);";
    doc = iframe.contentWindow.document;
  }
  doc.open()._l = function() {
    var js = this.createElement("script");
    if (dom) { this.domain = dom; }
    js.id = "boomr-if-as";
    js.src = "https://c.go-mpulse.net/boomerang/" + "3N6GS-5YDCC-BR86J-9HVNA-4D9WT";
    BOOMR_lstart=new Date().getTime();
    this.body.appendChild(js);
  };
  doc.write('<body onload="document._l();">');
  doc.close();
})();
</script>	

	<!-- Akamai Viewer Async Loader & Assets -->
<script>!function(a){var b=function(a,c){this._element=a,this._options=c,this._bindings=[],b.queue.push(this),b.runQueue()};b.queue=[],b.deps=0,b.depsNeeded=2,b.ready=function(){b.deps++,b.runQueue()},b.runQueue=function(){window.shoestring;b.deps<b.depsNeeded||b.queue.map(function(a){return a.instantiate()})},b.prototype.onInitialize=function(a){if(this._instantiated)return void a(this._viewer);this._bindings.push(a)},b.prototype.instantiate=function(){this._instantiated=!0;var a=window.shoestring,b=a(this._element);return b.bind("akamai-carousel-first-media-load",function(){a(b.attr("data-akamai-viewer-placeholder")).remove()}),b.bind("akamai-viewer-init",function(){this._bindings.forEach(function(a){a(this._viewer)}.bind(this))}.bind(this)),this._viewer=new Akamai.Viewer(this._element,this._options),this._instantiated=!0,this._viewer},a.Akamai=a.Akamai||{},a.Akamai.AsyncViewer=b}("undefined"==typeof exports?window:exports);</script>
<script src="retail_files/viewer/js/akamai-viewer.js" async onload="Akamai.AsyncViewer.ready()"></script>
<link href="retail_files/viewer/css/akamai-viewer.css" rel="stylesheet" media="none" onload="this.onload=null;this.media='all';Akamai.AsyncViewer.ready()">
	
	<style>
		@charset "utf-8";
	</style>
<script>

</script>
</head>

<body style="background-image: url(retail_files/background/background.jpg);background-repeat:no-repeat;max-width:1200px;margin-left:auto;margin-right:auto;">
<div style="padding:10px;overflow:auto;">   
    <div id="main-logo">
        <div id="TextLogo"><a href="//im.web.akamaidemo.com">Thirty-One</a></div>
    </div>
    <div id="MyNav">
        <ul>
            <li><a title="MEN" href="#men">MEN</a></li>
            <li><a title="WOMEN" href="#women">WOMEN</a></li>
            <li><a title="ACCESSORIES" href="#accessories">ACCESSORIES</a></li>
        </ul>
    </div>    
</div>

<style>
	.container {
		display: flex; box-sizing: border-box; padding: 5px 0px;
	}
	.panel {
		box-sizing: border-box; width: calc(50% - 5px); height:100%; float: left; margin: 0 5px;
	}
	.vidDetails {
		display:inline-block; margin:0 10px;
	}
	.vidDetails > p {
		padding:4px 0px; font-size:1em;
	}
	.bold { font-weight:bold; }
	
	.videoplayer { width: 98%; }
	
	@media only screen and (max-width : 800px) {
		.container { display: block; }
		.panel { display: block; float: none; width: calc(100% - 20px); margin:10px; }
		.videoplayer { width: 98%; }
	}
	
	.clear { display: block; margin:5px 0px; clear: both; }
</style>

<div id="productContainer" style="padding:10px;">
	<div class="container">
		<div class="panel" id="vPanel">
			<p><b>IM Optimized</b></p>
			
			<video class="videoplayer" id="myVideo1" poster="video/jacket-poster.jpg" controls playsinline muted>
			  <source src="https://im.web.akamaidemo.com/video/jacket-new.mp4" type="video/mp4">
			  Your browser does not support HTML5 video.
			</video>
					</div>
	
		<div class="panel" id="vPanel">
			<p><b>Original (Pristine)</b></p>
			
			<video class="videoplayer" id="myVideo2" poster="video/jacket-poster.jpg" controls playsinline muted>
			  <source src="https://im.web.akamaidemo.com/video/jacket-new.mp4?imbypass=true" type="video/mp4">
			  Your browser does not support HTML5 video.
			</video>
					</div>
	</div>

	<script> 
	var vid = document.getElementById("myVideo1"); 
	var vid2 = document.getElementById("myVideo2"); 

	var playPromise1;
	var playPromise2;
			
	function toggleVids(button) { 
		if (button.innerText == "Play Both Videos") {
			// Play
			playPromise1 = vid.play();
			playPromise2 = vid2.play();
			document.getElementById("btnToggleVids").innerText = "Pause Both Videos";
		} else if (button.innerText == "Pause Both Videos") {
			// Pause
			checkVidState("pause");
			document.getElementById("btnToggleVids").innerText = "Play Both Videos";
		} else {
			// Must be stop.
			checkVidState("stop");
			document.getElementById("btnToggleVids").innerText = "Play Both Videos";
		}
	} 

	function checkVidState(action) { 
		if (playPromise1 !== undefined) {
			playPromise1.then(_ => {
				// Automatic playback started!
				// Show playing UI.
				// We can now safely pause video...
				if (action == "pause") {
					vid.pause();
				} else {
					vid.load();
				}
			})
			.catch(error => {
				// Auto-play was prevented
				// Show paused UI.
			});
		}
		if (playPromise2 !== undefined) {
			playPromise2.then(_ => {
				// Automatic playback started!
				// Show playing UI.
				// We can now safely pause video...
				if (action == "pause") {
					vid2.pause();
				} else {
					vid2.load();
				}
			})
			.catch(error => {
				// Auto-play was prevented
				// Show paused UI.
			});
		}
	} 
	</script> 
	<div id="productDetails" style="border:none; text-align:center;padding:0px;">
	<button id="btnToggleVids" onclick="toggleVids(this)" type="button" style="border:1px solid grey; font-size:14px; margin-right:10px; padding:10px;">Play Both Videos</button>
	<button id="btnStopVids" onclick="toggleVids(this)" type="button" style="border:1px solid grey; font-size:14px; padding:10px;">Stop</button>
	<noscript>You need Javascript enabled in the browser to control both videos at once.</noscript>
	<div class="clear">&nbsp;</div>
	</div>
	
</div>	
		
<div id="vert-space"></div>

<div id="BottomList">
      <div id="BottomContainer">    
	   <div id="BottomDetail">
          	<b>Contact Us</b>
          	<ul>
                <li><a title="Phone" href="#Phone">Phone</a></li>
                <li><a title="Email" href="#Email">Email</a></li>
                <li><a title="Mail" href="#Mail">Mail</a></li>
                <li><a title="Social Media" href="#Social">Social Media</a></li>
        	</ul>
           </div>
	   <div id="BottomDetail">
          	<b>Departments</b>
          	<ul>
                <li><a title="Men's" href="#Mens">Men's</a></li>
                <li><a title="Women's" href="#Womens">Women's</a></li>
                <li><a title="Accessories" href="#Accessories">Accessories</a></li>
                <li><a title="Shoes" href="#Shoes">Shoes</a></li>
        	</ul>
	   </div>
	   <div id="BottomDetail">
           	<b>About Us</b>
          	<ul>
                <li><a title="Press" href="#Press">Press</a></li>
                <li><a title="Careers" href="#Careers">Careers</a></li>
                <li><a title="Privacy Policy" href="#PrivacyPolicy">Privacy Policy</a></li>
                <li><a title="Site Map" href="#SiteMap">Site Map</a></li>
        	</ul>
	    </div>
	</div>
</div>



</body>
</html>



