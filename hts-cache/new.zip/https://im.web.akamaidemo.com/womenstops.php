
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<meta http-equiv="Accept-CH" content="DPR, Viewport-Width, Width">
	<title>Thirty-One</title>
	<link rel="stylesheet" type="text/css" href="retail_files/styles.css">
	<script type='text/javascript'>
		/*
		var domain = '.akaimaging.com';
		var expires = new Date(); 
		expires.setDate(expires.getDate() + 365);
		document.cookie="im-pixel-density=" + window.devicePixelRatio + "; domain=" + domain + "; expires=" + expires + "; path=/";
		*/
	</script>	
<script>
(function(){
  if (window.BOOMR && window.BOOMR.version) { return; }
  var dom,doc,where,iframe = document.createElement("iframe"),win = window;

  function boomerangSaveLoadTime(e) {
    win.BOOMR_onload=(e && e.timeStamp) || new Date().getTime();
  }
  if (win.addEventListener) {
    win.addEventListener("load", boomerangSaveLoadTime, false);
  } else if (win.attachEvent) {
    win.attachEvent("onload", boomerangSaveLoadTime);
  }

  iframe.src = "javascript:void(0)";
  iframe.title = ""; iframe.role = "presentation";
  (iframe.frameElement || iframe).style.cssText = "width:0;height:0;border:0;display:none;";
  where = document.getElementsByTagName("script")[0];
  where.parentNode.insertBefore(iframe, where);

  try {
    doc = iframe.contentWindow.document;
  } catch(e) {
    dom = document.domain;
    iframe.src="javascript:var d=document.open();d.domain='"+dom+"';void(0);";
    doc = iframe.contentWindow.document;
  }
  doc.open()._l = function() {
    var js = this.createElement("script");
    if (dom) { this.domain = dom; }
    js.id = "boomr-if-as";
    js.src = "https://c.go-mpulse.net/boomerang/" + "3N6GS-5YDCC-BR86J-9HVNA-4D9WT";
    BOOMR_lstart=new Date().getTime();
    this.body.appendChild(js);
  };
  doc.write('<body onload="document._l();">');
  doc.close();
})();
</script>	

	<!-- Akamai Viewer Async Loader & Assets -->
<script>!function(a){var b=function(a,c){this._element=a,this._options=c,this._bindings=[],b.queue.push(this),b.runQueue()};b.queue=[],b.deps=0,b.depsNeeded=2,b.ready=function(){b.deps++,b.runQueue()},b.runQueue=function(){window.shoestring;b.deps<b.depsNeeded||b.queue.map(function(a){return a.instantiate()})},b.prototype.onInitialize=function(a){if(this._instantiated)return void a(this._viewer);this._bindings.push(a)},b.prototype.instantiate=function(){this._instantiated=!0;var a=window.shoestring,b=a(this._element);return b.bind("akamai-carousel-first-media-load",function(){a(b.attr("data-akamai-viewer-placeholder")).remove()}),b.bind("akamai-viewer-init",function(){this._bindings.forEach(function(a){a(this._viewer)}.bind(this))}.bind(this)),this._viewer=new Akamai.Viewer(this._element,this._options),this._instantiated=!0,this._viewer},a.Akamai=a.Akamai||{},a.Akamai.AsyncViewer=b}("undefined"==typeof exports?window:exports);</script>
<script src="retail_files/viewer/js/akamai-viewer.js" async onload="Akamai.AsyncViewer.ready()"></script>
<link href="retail_files/viewer/css/akamai-viewer.css" rel="stylesheet" media="none" onload="this.onload=null;this.media='all';Akamai.AsyncViewer.ready()">
	
	<style>
		@charset "utf-8";
	</style>
<script>

</script>
</head>

<body style="background-image: url(retail_files/background/background.jpg);background-repeat:no-repeat;max-width:1200px;margin-left:auto;margin-right:auto;">
<div style="padding:10px;overflow:auto;">   
    <div id="main-logo">
        <div id="TextLogo"><a href="//im.web.akamaidemo.com">Thirty-One</a></div>
    </div>
    <div id="MyNav">
        <ul>
            <li><a title="MEN" href="#men">MEN</a></li>
            <li><a title="WOMEN" href="#women">WOMEN</a></li>
            <li><a title="ACCESSORIES" href="#accessories">ACCESSORIES</a></li>
        </ul>
    </div>    
</div>




<div id="productContainer" style="padding:10px;" >

	<div id="productAction">
		Women's Polo <b>£49.99</b><br><br>
		<span id="action_detail">
		<br><font color="maroon">* NEW IN *</font>
		<br><br><img src="retail_files/reviews.JPG">
		<br><a href="#" onclick="return false;" class="_links">18 Reviews</a> 
		<br><br><br><br><select class="_dropdown"><option>Small</option><option>Medium</option><option>Large</option></select>
		<br><a href="#" onclick="return false;" class="_links">Size guide</a>
		</span>
		<br><br><select class="_dropdown" onChange="changeTag(this.value);"><option value="Green">Green</option><option value="Blue">Blue</option><option value="Red">Red</option><option value="Pink">Pink</option></select>
		<br><br><button class="_button">Add to Basket</button>
		<br><br><br><img src="retail_files/social.JPG?1">
	</div>	

	<div id="productViewer" ></div>
	
<script>
  
  var asyncViewer = new Akamai.AsyncViewer( document.getElementById( "productViewer" ), {
    carousel: {
      aspectratio: 60
    },
    items: {
	  //tags: ["Pink","Blue"],	
      uri: "/retail_files/viewer/product.imviewer?aki_collection=123456"
    }
  });
  
asyncViewer.onInitialize(function(_viewer){
	window.viewer = _viewer;
});
 




 
  //viewer.switchTag("Blue");
function changeTag(color){
 //alert(color);	
 viewer.switchTag(color);
}	
</script>


	<div id="productDetails">
		<b>Details</b>
		<br><br>
		Introduced in 1950, our Polo shirt now comes in a variety of colors and styles but remains just as iconic as the original. This stretch cotton version looks chic with almost anything, from jeans to a ballgown skirt.
		<br><br>
		<ul class="_list">
			<li>Boxy fit.</li>
			<li>Size medium has a 23¾" back body length and a 43" bust.</li>
			<li>Ribbed Polo collar. Five-button placket.</li>
			<li>Short sleeves with ribbed armbands.</li>
			<li>Uneven vented hem. Lined at the body.</li>
			<li>Shell: 100% cotton. Trim: 69% viscose, 28% nylon, 3% elastane. Lining: 100% polyester.</li>
			<li>Model is 5'10"/178 cm and has a 32" bust. She wears a size small.</li>
		</ul>
	</div>


	
</div>	
		
<div id="vert-space"></div>

<div id="BottomList">
      <div id="BottomContainer">    
	   <div id="BottomDetail">
          	<b>Contact Us</b>
          	<ul>
                <li><a title="Phone" href="#Phone">Phone</a></li>
                <li><a title="Email" href="#Email">Email</a></li>
                <li><a title="Mail" href="#Mail">Mail</a></li>
                <li><a title="Social Media" href="#Social">Social Media</a></li>
        	</ul>
           </div>
	   <div id="BottomDetail">
          	<b>Departments</b>
          	<ul>
                <li><a title="Men's" href="#Mens">Men's</a></li>
                <li><a title="Women's" href="#Womens">Women's</a></li>
                <li><a title="Accessories" href="#Accessories">Accessories</a></li>
                <li><a title="Shoes" href="#Shoes">Shoes</a></li>
        	</ul>
	   </div>
	   <div id="BottomDetail">
           	<b>About Us</b>
          	<ul>
                <li><a title="Press" href="#Press">Press</a></li>
                <li><a title="Careers" href="#Careers">Careers</a></li>
                <li><a title="Privacy Policy" href="#PrivacyPolicy">Privacy Policy</a></li>
                <li><a title="Site Map" href="#SiteMap">Site Map</a></li>
        	</ul>
	    </div>
	</div>
</div>



</body>
</html>



